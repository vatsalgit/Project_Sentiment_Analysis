runfile('C:/Users/vatsal/rural_water_supply.py', wdir='C:/Users/vatsal')
storage = [pumprate*2*60]
storage[0]
runfile('C:/Users/vatsal/rural_water_supply.py', wdir='C:/Users/vatsal')
%reset
runfile('C:/Users/vatsal/rural_water_supply.py', wdir='C:/Users/vatsal')
1
runfile('C:/Users/vatsal/rural_water_supply.py', wdir='C:/Users/vatsal')

##---(Sun Jan 17 13:54:57 2016)---
runfile('C:/Users/vatsal/rural_water_supply.py', wdir='C:/Users/vatsal')
pumprate = demand/(totalpump*60)
pumprate
supplyrate = demand/(totalsupply*60)
supplyrate
storage = [pumprate*2*60]
storage
runfile('C:/Users/vatsal/rural_water_supply.py', wdir='C:/Users/vatsal')
%matplotlib qt
runfile('C:/Users/vatsal/rural_water_supply.py', wdir='C:/Users/vatsal')
storage
supplyrate = demand/(totalsupply*60)
supplyrate
len(storage)
len(infow)
len(inflow)
runfile('C:/Users/vatsal/rural_water_supply.py', wdir='C:/Users/vatsal')
storage
runfile('C:/Users/vatsal/rural_water_supply.py', wdir='C:/Users/vatsal')
%clear
runfile('C:/Users/vatsal/rural_water_supply.py', wdir='C:/Users/vatsal')

##---(Sun Jan 17 18:22:39 2016)---
runfile('C:/Users/vatsal/features.py', wdir='C:/Users/vatsal')
len(word_features)
word_features
%clear
documents
documents[0]
def find_features(document):
    words = set(document)
    features = {}
    for w in word_features:
        features[w] = (w in words)
    
    return features


print((find_features(movie_reviews.words('neg/cv000_29416.txt'))))

##---(Sun Jan 24 11:20:31 2016)---
documents[0]
import nltk
import random
from nltk.corpus import movie_reviews

documents = [(list(movie_reviews.words(fileid)), category)
             for category in movie_reviews.categories()
             for fileid in movie_reviews.fileids(category)]

documents[0]
random.shuffle(documents)

all_words = []

for w in movie_reviews.words():
    all_words.append(w.lower())


all_words = nltk.FreqDist(all_words)

word_features = list(all_words.keys())[:3000]

def find_features(document):
    words = set(document)
    features = {}
    for w in word_features:
        features[w] = (w in words)
    
    return features


print((find_features(movie_reviews.words('neg/cv000_29416.txt'))))

##---(Tue Jan 26 14:01:19 2016)---
runfile('C:/Users/vatsal/features.py', wdir='C:/Users/vatsal')
featuresets = [(find_features(rev), category) for (rev, category) in documents]
len(featuresets)
featuresets
featuresets[0]
len(all_words)
all_words [1:10]
all_words [range(1,10)]
all_words[5]
all_words
all_words.keys
all_words.keys()
for i in range(1,10):    print(all_words[i])
for i in range(1,100):    print(all_words[i])
x = list(all_words)
x[1:10]
x[1:100]
all_words.most_common()
len(all_words.most_common())
somestupidlist = ["Great","Great","Awesome","Awesome","Good","Good","Good","Hate"]
x = []for w in somestupidlist:    x.append(w.lower())
x = nltk.FreqDist(x)
x
x.most_common
x.most_common()
x.keys
x.keys()
x = x.most_common()
x.keys()
x
x[0]
x[0][0]
%clear
runfile('C:/Users/vatsal/OneDrive/Sentiment_Python/extract_features_and_TRAIN.py', wdir='C:/Users/vatsal/OneDrive/Sentiment_Python')
import nltk
import random
from nltk.tokenize import word_tokenize
short_pos = open("short_reviews/positive.txt","r").read()
short_neg = open("short_reviews/negative.txt","r").read()
runfile('C:/Users/vatsal/OneDrive/Sentiment_Python/extract_features_and_TRAIN.py', wdir='C:/Users/vatsal/OneDrive/Sentiment_Python')
all_words = []
reviews = []


#  j is adject, r is adverb, and v is verb
#allowed_word_types = ["J","R","V"]
allowed_word_types = ["J"]
for p in short_pos.split('\n'):
    reviews.append( (p, "pos") )
    words = word_tokenize(p)
    pos = nltk.pos_tag(words)
    for w in pos:
        if w[1][0] in allowed_word_types:
            all_words.append(w[0].lower())

save_reviews = open("pickled_algos/reviews.pickle","wb")
pickle.dump(reviews, save_reviews)
save_reviews.close()
all_words = list(all_words)
all_words[0:10]
freq = nltk.FreqDist(all_words)
freq = list(freq)[1:10]
freq = nltk.FreqDist(all_words)
freq = list(freq)
freq[1:10]
freq = nltk.FreqDist(all_words)
print(freq)
freq
freq.most_common()
freq = freq.most_common()
freq[0]
freq[0:10]
freq[0:25]
len(freq)
freq = nltk.FreqDist(all_words)
freq = freq.most_common()
freq
freq[0:5]
freq[0:5][0]
freq[0][0]
freq[0][1]
freq[1][0]
word_features = [freq[key][0] for key in range(0,4000)]
word_features
word_features[0:100]
save_word_features = open("pickled_algos/word_features.pickle","wb")
pickle.dump(word_features, save_word_features)
save_word_features.close()
reviews[0:10]
random.shuffle(reviews)
reviews[1:10]
reviews[1000:1010]
def find_features(review):
    words = word_tokenize(review)
    features = {}
    for w in word_features:
        features[w] = (w in words)
    
    return features


featuresets = [(find_features(rev), category) for (rev, category) in reviews]
featuresets[0:2]
featuresets[0]
featuresets[1]
featuresets[5]
random.shuffle(featuresets)
print(len(featuresets))
save_featuresets = open("pickled_algos/final_featuresets.pickle","wb")
pickle.dump(featuresets,save_featuresets)
save_featuresets.close()
runfile('C:/Users/vatsal/OneDrive/Sentiment_Python/train_classifiers.py', wdir='C:/Users/vatsal/OneDrive/Sentiment_Python')
voted_classifier = VoteClassifier(classifier,
                                  LinearSVC_classifier,
                                  SGDC_classifier,
                                  MNB_classifier,
                                  BernoulliNB_classifier,
                                  LogisticRegression_classifier)

print("voted_classifier accuracy percent:", (nltk.classify.accuracy(voted_classifier, testing_set))*100)

print("Classification:", voted_classifier.classify(testing_set[0][0]), "Confidence %:",voted_classifier.confidence(testing_set[0][0])*100)
print("Classification:", voted_classifier.classify(testing_set[1][0]), "Confidence %:",voted_classifier.confidence(testing_set[1][0])*100)
print("Classification:", voted_classifier.classify(testing_set[2][0]), "Confidence %:",voted_classifier.confidence(testing_set[2][0])*100)
print("Classification:", voted_classifier.classify(testing_set[3][0]), "Confidence %:",voted_classifier.confidence(testing_set[3][0])*100)
print("Classification:", voted_classifier.classify(testing_set[4][0]), "Confidence %:",voted_classifier.confidence(testing_set[4][0])*100)
print("Classification:", voted_classifier.classify(testing_set[5][0]), "Confidence %:",voted_classifier.confidence(testing_set[5][0])*100)

voted_classifier = VoteClassifier(classifier,
                                  LinearSVC_classifier,
                                  MNB_classifier,
                                  BernoulliNB_classifier,
                                  LogisticRegression_classifier)

print("voted_classifier accuracy percent:", (nltk.classify.accuracy(voted_classifier, testing_set))*100)

print("Classification:", voted_classifier.classify(testing_set[0][0]), "Confidence %:",voted_classifier.confidence(testing_set[0][0])*100)
print("Classification:", voted_classifier.classify(testing_set[1][0]), "Confidence %:",voted_classifier.confidence(testing_set[1][0])*100)
print("Classification:", voted_classifier.classify(testing_set[2][0]), "Confidence %:",voted_classifier.confidence(testing_set[2][0])*100)
print("Classification:", voted_classifier.classify(testing_set[3][0]), "Confidence %:",voted_classifier.confidence(testing_set[3][0])*100)
print("Classification:", voted_classifier.classify(testing_set[4][0]), "Confidence %:",voted_classifier.confidence(testing_set[4][0])*100)
print("Classification:", voted_classifier.classify(testing_set[5][0]), "Confidence %:",voted_classifier.confidence(testing_set[5][0])*100)
print("Classification:", voted_classifier.classify("I hate the movie"), "Confidence %:",voted_classifier.confidence("I hate the movie")*100)
testing_set[0][0]