            i = i+1
# *** Spyder Python Console History Log ***
        
        print(len(substring))

##---(Sun Jan 31 23:17:27 2016)---
s = "abcabc"
s = list(s)
substring = [s[0]]
substring = [s[i] for i in range(1,len(s)+1) if s[i] not in substring]

s = "abcabc"
s = list(s)
substring = [s[0]]
substring = [s[i] for i in range(1,len(s)) if s[i] not in substring]

s = "abcabc"
s = list(s)
substring = [s[0]]
while s not in substring:
    substring.append(s)

s = "abcabc"
s = list(s)
substring = [s[0]]
i = 1
for i in range(1,len(s)+1):
    
    if s[i] not in substring:
        substring.append(s[i])
    else:
        break

s = "abc"
s = list(s)
substring = [s[0]]
i = 1
for i in range(1,len(s)+1):
    
    if s[i] not in substring:
        substring.append(s[i])
    else:
        break

s = "abc"
s = list(s)
substring = [s[0]]

for i in range(1,len(s)+1):
    
    if s[i] not in substring:
        substring.append(s[i])
    else:
        break

s = "abc"
s = list(s)
substring = [s[0]]
for i in range(1,len(s)+1):
    
    if s[i] not in substring:
        substring.append(s[i])
    else:
        break

for i in range(1,len(s)):
    
    if s[i] not in substring:
        substring.append(s[i])
    else:
        break

s = "abcc"
s = list(s)
substring = [s[0]]

for i in range(1,len(s)):
    
    if s[i] not in substring:
        substring.append(s[i])
    else:
        break

s = "bbbbb"
s = list(s)
substring = [s[0]]

for i in range(1,len(s)):
    
    if s[i] not in substring:
        substring.append(s[i])
    else:
        break

s = "abcclop"
s = list(s)
substring = [s[0]]

for i in range(1,len(s)):
    
    if s[i] not in substring:
        substring.append(s[i])
    else:
        break


##---(Mon Feb  1 10:47:33 2016)---
s = "abcabcclmnop"
s = list(s)
substring = [s[0]]

for i in range(1,len(s)):
    
    if s[i] not in substring:
        substring.append(s[i])
    elif s[i] in substring:
        lengths= []
        lengths.append(len(substring))
        substring = []
        substring.append[s[i]]

s = "abcabcclmnop"
s = list(s)
substring = [s[0]]

for i in range(1,len(s)):
    
    if s[i] not in substring:
        substring.append(s[i])

s = "abcabcclmnop"
s = list(s)
substring = [s[0]]

for i in range(1,len(s)):
    
    if s[i] not in substring:
        substring.append(s[i])
    elif s[i] in substring:
        lengths= []
        lengths.append(len(substring))

s = "abcabcclmnop"
s = list(s)
substring = [s[0]]

for i in range(1,len(s)):
    
    if s[i] not in substring:
        substring.append(s[i])
    elif s[i] in substring:
        lengths= []
        lengths.append(len(substring))
        substring = []
        substring.append[s[i]]

s = "abcabcclmnop"
s = list(s)
substring = [s[0]]

for i in range(1,len(s)):
    
    if s[i] not in substring:
        substring.append(s[i])
    elif s[i] in substring:
        lengths= []
        lengths.append(len(substring))
        substring = []
        substring.append(s[i])

s = "abcabcclmnopp"
s = list(s)
substring = [s[0]]

for i in range(1,len(s)):
    
    if s[i] not in substring:
        substring.append(s[i])
    elif s[i] in substring:
        lengths= []
        lengths.append(len(substring))
        substring = []
        substring.append(s[i])

for i in range(1,len(s)):
    
    if s[i] not in substring:
        substring.append(s[i])
    elif s[i] in substring:
        lengths= []
        lengths.append(len(substring))

s = "abcabcclmnopp"
s = list(s)
substring = [s[0]]

for i in range(1,len(s)+1):
    
    if s[i] not in substring:
        substring.append(s[i])
    elif s[i] in substring:
        lengths= []
        lengths.append(len(substring))
        substring = []
        substring.append(s[i])

for i in range(1,len(s)):
    
    if s[i] not in substring:
        substring.append(s[i])
    elif s[i] in substring:
        lengths= []
        lengths.append(len(substring))
        substring = []
        substring.append(s[i])

s = "pppp"
s = list(s)
substring = [s[0]]

for i in range(1,len(s)):
    
    if s[i] not in substring:
        substring.append(s[i])
    elif s[i] in substring:
        lengths= []
        lengths.append(len(substring))
        substring = []
        substring.append(s[i])

s = "abcc"
s = list(s)
substring = [s[0]]

for i in range(1,len(s)):
    
    if s[i] not in substring:
        substring.append(s[i])
    elif s[i] in substring:
        lengths= []
        lengths.append(len(substring))
        substring = []
        substring.append(s[i])


s = "abcd"
s = list(s)
substring = [s[0]]

for i in range(1,len(s)):
    
    if s[i] not in substring:
        substring.append(s[i])
    elif s[i] in substring:
        lengths= []
        lengths.append(len(substring))
        substring = []
        substring.append(s[i])

s = "abcdabcde"
s = list(s)
substring = [s[0]]

for i in range(1,len(s)):
    
    if s[i] not in substring:
        substring.append(s[i])
    elif s[i] in substring:
        lengths= []
        lengths.append(len(substring))
        substring = []
        substring.append(s[i])

s = "abcccclmnop"
s = list(s)
substring = [s[0]]

for i in range(1,len(s)):
    
    if s[i] not in substring:
        substring.append(s[i])
    elif s[i] in substring:
        lengths= []
        lengths.append(len(substring))
        substring = []
        substring.append(s[i])

s = "abcccrrrrrlkajjlmnop"
s = list(s)
substring = [s[0]]

for i in range(1,len(s)):
    
    if s[i] not in substring:
        substring.append(s[i])
    elif s[i] in substring:
        lengths= []
        lengths.append(len(substring))
        substring = []
        substring.append(s[i])

s = "aab"
s = list(s)
substring = [s[0]]

for i in range(1,len(s)):
    
    if s[i] not in substring:
        substring.append(s[i])
    elif s[i] in substring:
        lengths= []
        lengths.append(len(substring))
        substring = []
        substring.append(s[i])

s = "abcde"
s = list(s)
substring = [s[0]]

for i in range(1,len(s)):
    
    if s[i] not in substring:
        substring.append(s[i])
    elif s[i] in substring:
        substring = []
        substring.append(s[i])
    
    return len(substring)

s = "abcdd"
s = list(s)
substring = [s[0]]

for i in range(1,len(s)):
    
    if s[i] not in substring:
        flag = 1
        substring.append(s[i])
    elif s[i] in substring:
        flag = 0
        substring = []
        substring.append(s[i])
    
    return len(substring)


s = "abcdd"
s = list(s)
substring = [s[0]]

for i in range(1,len(s)):
    
    if s[i] not in substring:
        flag = 1
        substring.append(s[i])
    elif s[i] in substring:
        flag = 0
        substring = []
        substring.append(s[i])

s = "abcdabcccclmoerst"
s = list(s)
substring = [s[0]]

for i in range(1,len(s)):
    
    if s[i] not in substring:
        flag = 1
        substring.append(s[i])
    elif s[i] in substring:
        flag = 0
        substring = []
        substring.append(s[i])

s = "lmoerstabcdabcccc"
s = list(s)
substring = [s[0]]

for i in range(1,len(s)):
    
    if s[i] not in substring:
        flag = 1
        substring.append(s[i])
    elif s[i] in substring:
        flag = 0
        substring = []
        substring.append(s[i])

s = "artbbd"
s = list(s)
substring = [s[0]]

for i in range(1,len(s)):
    
    if s[i] not in substring:
        substring.append(s[i])
    elif s[i] in substring:
        lengths= []
        lengths.append(len(substring))
        substring = []
        substring.append(s[i])

s = "artbbd"
s = list(s)
substring = [s[0]]

for i in range(1,len(s)):
    
    if s[i] not in substring:
        substring.append(s[i])
    elif s[i] in substring:
        lengths= []
        lengths.append(len(substring))
        substring = []
        substring.append(s[i])
        i =i+1

s = "abcde"
s = list(s)
substring = [s[0]]

for i in range(1,len(s)):
    
    if s[i] not in substring:
        substring.append(s[i])
    elif s[i] in substring:
        lengths= []
        lengths.append(len(substring))
        substring = []
        substring.append(s[i])
        i =i+1

s = "abcdd"
s = list(s)
substring = [s[0]]

for i in range(1,len(s)):
    
    if s[i] not in substring:
        substring.append(s[i])
    elif s[i] in substring:
        lengths= []
        lengths.append(len(substring))
        substring = []
        substring.append(s[i])
        i =i+1

s = "abcdmnopqrstdd"
s = list(s)
substring = [s[0]]

for i in range(1,len(s)):
    
    if s[i] not in substring:
        substring.append(s[i])
    elif s[i] in substring:
        lengths= []
        lengths.append(len(substring))
        substring = []
        substring.append(s[i])
        i =i+1

s = "abcdmnopqrstdd"
s = list(s)
substring = [s[0]]

for i in range(1,len(s)):
    
    if s[i] not in substring:
        substring.append(s[i])
    elif s[i] in substring:
        lengths= []
        lengths.append(len(substring))
        substring = []
        substring.append(s[i])

lengths
polarity,confidence = sentiment("One of the best movies ever to be produced in the history of cinema")
print (polarity,confidence)
runfile('C:/Users/vatsal/OneDrive/Sentiment_Python/final_demo_v1.0.0.py', wdir='C:/Users/vatsal/OneDrive/Sentiment_Python')
%reset
%clear
debugfile('C:/Users/vatsal/OneDrive/Sentiment_Python/train_classifiers.py', wdir='C:/Users/vatsal/OneDrive/Sentiment_Python')
from testing import sentiment

polarity,confidence = sentiment("That was an amzing movie because Shahrukh acted in it")
print (polarity,confidence)

from testing import sentiment

polarity,confidence = sentiment("One of the worst movies I have ever seen")
print (polarity,confidence)