import random
from nltk.tokenize import word_tokenize
short_pos = open("short_reviews/positive.txt","r").read()
short_neg = open("short_reviews/negative.txt","r").read()
runfile('C:/Users/vatsal/OneDrive/Sentiment_Python/extract_features_and_TRAIN.py', wdir='C:/Users/vatsal/OneDrive/Sentiment_Python')
all_words = []
reviews = []


#  j is adject, r is adverb, and v is verb
#allowed_word_types = ["J","R","V"]
allowed_word_types = ["J"]
for p in short_pos.split('\n'):
    reviews.append( (p, "pos") )
    words = word_tokenize(p)
    pos = nltk.pos_tag(words)
    for w in pos:
        if w[1][0] in allowed_word_types:
            all_words.append(w[0].lower())

save_reviews = open("pickled_algos/reviews.pickle","wb")
pickle.dump(reviews, save_reviews)
save_reviews.close()
all_words = list(all_words)
all_words[0:10]
freq = nltk.FreqDist(all_words)
freq = list(freq)[1:10]
freq = nltk.FreqDist(all_words)
freq = list(freq)
freq[1:10]
freq = nltk.FreqDist(all_words)
print(freq)
freq
freq.most_common()
freq = freq.most_common()
freq[0]
freq[0:10]
freq[0:25]
len(freq)
freq = nltk.FreqDist(all_words)
freq = freq.most_common()
freq
freq[0:5]
freq[0:5][0]
freq[0][0]
freq[0][1]
freq[1][0]
word_features = [freq[key][0] for key in range(0,4000)]
word_features
word_features[0:100]
save_word_features = open("pickled_algos/word_features.pickle","wb")
pickle.dump(word_features, save_word_features)
save_word_features.close()
reviews[0:10]
random.shuffle(reviews)
reviews[1:10]
reviews[1000:1010]
def find_features(review):
    words = word_tokenize(review)
    features = {}
    for w in word_features:
        features[w] = (w in words)
    
    return features


featuresets = [(find_features(rev), category) for (rev, category) in reviews]
featuresets[0:2]
featuresets[0]
featuresets[1]
featuresets[5]
random.shuffle(featuresets)
print(len(featuresets))
save_featuresets = open("pickled_algos/final_featuresets.pickle","wb")
pickle.dump(featuresets,save_featuresets)
save_featuresets.close()
runfile('C:/Users/vatsal/OneDrive/Sentiment_Python/train_classifiers.py', wdir='C:/Users/vatsal/OneDrive/Sentiment_Python')
voted_classifier = VoteClassifier(classifier,
                                  LinearSVC_classifier,
                                  SGDC_classifier,
                                  MNB_classifier,
                                  BernoulliNB_classifier,
                                  LogisticRegression_classifier)

print("voted_classifier accuracy percent:", (nltk.classify.accuracy(voted_classifier, testing_set))*100)

print("Classification:", voted_classifier.classify(testing_set[0][0]), "Confidence %:",voted_classifier.confidence(testing_set[0][0])*100)
print("Classification:", voted_classifier.classify(testing_set[1][0]), "Confidence %:",voted_classifier.confidence(testing_set[1][0])*100)
print("Classification:", voted_classifier.classify(testing_set[2][0]), "Confidence %:",voted_classifier.confidence(testing_set[2][0])*100)
print("Classification:", voted_classifier.classify(testing_set[3][0]), "Confidence %:",voted_classifier.confidence(testing_set[3][0])*100)
print("Classification:", voted_classifier.classify(testing_set[4][0]), "Confidence %:",voted_classifier.confidence(testing_set[4][0])*100)
print("Classification:", voted_classifier.classify(testing_set[5][0]), "Confidence %:",voted_classifier.confidence(testing_set[5][0])*100)

voted_classifier = VoteClassifier(classifier,
                                  LinearSVC_classifier,
                                  MNB_classifier,
                                  BernoulliNB_classifier,
                                  LogisticRegression_classifier)

print("voted_classifier accuracy percent:", (nltk.classify.accuracy(voted_classifier, testing_set))*100)

print("Classification:", voted_classifier.classify(testing_set[0][0]), "Confidence %:",voted_classifier.confidence(testing_set[0][0])*100)
print("Classification:", voted_classifier.classify(testing_set[1][0]), "Confidence %:",voted_classifier.confidence(testing_set[1][0])*100)
print("Classification:", voted_classifier.classify(testing_set[2][0]), "Confidence %:",voted_classifier.confidence(testing_set[2][0])*100)
print("Classification:", voted_classifier.classify(testing_set[3][0]), "Confidence %:",voted_classifier.confidence(testing_set[3][0])*100)
print("Classification:", voted_classifier.classify(testing_set[4][0]), "Confidence %:",voted_classifier.confidence(testing_set[4][0])*100)
print("Classification:", voted_classifier.classify(testing_set[5][0]), "Confidence %:",voted_classifier.confidence(testing_set[5][0])*100)
print("Classification:", voted_classifier.classify("I hate the movie"), "Confidence %:",voted_classifier.confidence("I hate the movie")*100)
testing_set[0][0]

##---(Sun Jan 31 11:38:37 2016)---
runfile('C:/Users/vatsal/OneDrive/Sentiment_Python/final_demo_v1.0.0.py', wdir='C:/Users/vatsal/OneDrive/Sentiment_Python')
polarity
confidence
runfile('C:/Users/vatsal/OneDrive/Sentiment_Python/final_demo_v1.0.0.py', wdir='C:/Users/vatsal/OneDrive/Sentiment_Python')
polarity,confidence = sentiment("It was a very good movie")
print (polarity,confidence)
polarity,confidence = sentiment("That was an amazing movie because I just loved the way Shahrukh acted in it")
print (polarity,confidence)
polarity,confidence = sentiment("I simply hated the movie, it did not have any action")
print (polarity,confidence)
polarity,confidence = sentiment("Breathtaking is just one word to describe a movie like this,Amazed!,Mesmerized,Superb")
print (polarity,confidence)
polarity,confidence = sentiment("Amazed!,Mesmerized,Superb")
print (polarity,confidence)
get_features = open("pickled_algos/final_featuresets.pickle", "rb")
featuresets = pickle.load(get_features)
get_features.close()
import pickle
get_features = open("pickled_algos/final_featuresets.pickle", "rb")
featuresets = pickle.load(get_features)
get_features.close()
len(featuresets)
featuresets[0]
polarity,confidence = sentiment("The movie was illuminating and good-natured")
print (polarity,confidence)
polarity,confidence = sentiment("I did not like the movie, It had no romance")
print (polarity,confidence)
polarity,confidence = sentiment("I did liked the movie, It had romance")
print (polarity,confidence)
polarity,confidence = sentiment("I liked the movie, It had romance")
print (polarity,confidence)
polarity,confidence = sentiment("I loved the movie")
print (polarity,confidence)
polarity,confidence = sentiment("That was a watchable movie")
print (polarity,confidence)
polarity,confidence = sentiment("That was an average movie")
print (polarity,confidence)
confidence = sentiment("That was a realy really boring movie,It was very slow")
print (polarity,confidence)
polarity,confidence = sentiment("That was a realy really boring movie,It was very slow")
print (polarity,confidence)
polarity,confidence = sentiment("One of the worst movies ever to be produced in the history of cinema")
print (polarity,confidence)
polarity,confidence = sentiment("One of the best movies ever to be produced in the history of cinema")
print (polarity,confidence)