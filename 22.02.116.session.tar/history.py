 
	#prints metrics to show how well the feature selection did
	print ('train on %d instances, test on %d instances' % (len(trainFeatures), len(testFeatures)))
	print ('accuracy:', nltk.classify.util.accuracy(classifier, testFeatures))

#	print ('pos precision:', nltk.metrics.precision(referenceSets['pos'], testSets['pos']))
#	print ('pos recall:', nltk.metrics.recall(referenceSets['pos'], testSets['pos']))
#	print ('neg precision:', nltk.metrics.precision(referenceSets['neg'], testSets['neg']))
#	print ('neg recall:', nltk.metrics.recall(referenceSets['neg'], testSets['neg']))
	classifier.show_most_informative_features(10)

#creates a feature selection mechanism that uses all words
def make_full_dict(words):
	return dict([(word, True) for word in words])


#tries using all words as the feature selection mechanism
print ('using all words as features')
evaluate_features(make_full_dict)

#scores words based on chi-squared test to show information gain (http://streamhacker.com/2010/06/16/text-classification-sentiment-analysis-eliminate-low-information-features/)
def create_word_scores():
	#creates lists of all positive and negative words
	posWords = []
	negWords = []
	with open('short_reviews/positive.txt', 'r') as posSentences:
		for i in posSentences:
			posWord = re.findall(r"[\w']+|[.,!?;]", i.rstrip())
			posWords.append(posWord)
	with open('short_reviews/negative.txt', 'r') as negSentences:
		for i in negSentences:
			negWord = re.findall(r"[\w']+|[.,!?;]", i.rstrip())
			negWords.append(negWord)
	posWords = list(itertools.chain(*posWords))
	negWords = list(itertools.chain(*negWords))
 
	#build frequency distibution of all words and then frequency distributions of words within positive and negative labels
	word_fd = FreqDist()
	cond_word_fd = ConditionalFreqDist()
	for word in posWords:
		word_fd[word.lower()] += 1
		cond_word_fd['pos'][word.lower()] += 1
	for word in negWords:
		word_fd[word.lower()] += 1
		cond_word_fd['neg'][word.lower()] += 1
 
	#finds the number of positive and negative words, as well as the total number of words
	pos_word_count = cond_word_fd['pos'].N()
	neg_word_count = cond_word_fd['neg'].N()
	total_word_count = pos_word_count + neg_word_count
 
	#builds dictionary of word scores based on chi-squared test
	word_scores = {}
	for word, freq in word_fd.items():
		pos_score = BigramAssocMeasures.chi_sq(cond_word_fd['pos'][word], (freq, pos_word_count), total_word_count)
		neg_score = BigramAssocMeasures.chi_sq(cond_word_fd['neg'][word], (freq, neg_word_count), total_word_count)
		word_scores[word] = pos_score + neg_score
 
	return word_scores


#finds word scores
word_scores = create_word_scores()
word_scores
words
def make_full_dict(words):
	return dict([(word, True) for word in words])

make_full_dict
make_full_dict()
def a(x):
    return "a(%s)" % (x,)


def b(f,x):
    return f(x)


print b(a)
def a(x):
    return "a(%s)" % (x,)


def b(f,x):
    return f(x)


print b(a,10)
def a(x):
    return "a(%s)" % (x,)


def b(f,x):
    return f(x)


print (b(a,10))
print (b(a)
def a(x):
    return "a(%s)" % (x,)


def b(f,x):
    return f(x)


print (b(a))
def a(x):
    return "a(%s)" % (x,)


def b(f):
    return f(x)


print (b(a))
def a(x):
    return "a(%s)" % (x,)


def b(f):
    return f


print (b(a))
%clear
best_vals = sorted(word_scores.items(), key=lambda (w, s): s, reverse=True)[:number]
best_vals = sorted(word_scores.items(), key=lambda (w, s): s, reverse=True)
best_vals = sorted(word_scores.items(), key=lambda (w, s): s)
word_scores
word_scores.items()
%clear
word_scores[0]
word_scores
%clear
best = sorted(word_scores.items(),key = lambda x : x[1],reverse =True)
best
best[:5000]
%clear
runfile('C:/Users/vatsal/OneDrive/Sentiment_Module_Twitter_1.1/Improved_Complete.py', wdir='C:/Users/vatsal/OneDrive/Sentiment_Module_Twitter_1.1')

##---(Mon Feb 22 11:00:01 2016)---
runfile('C:/Users/vatsal/OneDrive/Sentiment_Module_Twitter_1.1/Improved_Complete.py', wdir='C:/Users/vatsal/OneDrive/Sentiment_Module_Twitter_1.1')
import nltk
from nltk.metrics import precision
runfile('C:/Users/vatsal/OneDrive/Sentiment_Module_Twitter_1.1/Improved_Complete.py', wdir='C:/Users/vatsal/OneDrive/Sentiment_Module_Twitter_1.1')
runfile('C:/Users/vatsal/OneDrive/Sentiment_Module_Twitter_1.1/evaluate_features.py', wdir='C:/Users/vatsal/OneDrive/Sentiment_Module_Twitter_1.1')
posFeatures
posFeatures[0]
runfile('C:/Users/vatsal/OneDrive/Sentiment_Module_Twitter_1.1/evaluate_features.py', wdir='C:/Users/vatsal/OneDrive/Sentiment_Module_Twitter_1.1')
%clear
%reset
%clear
runfile('C:/Users/vatsal/OneDrive/Sentiment_Module_Twitter_1.1/final_demo_v1.1.py', wdir='C:/Users/vatsal/OneDrive/Sentiment_Module_Twitter_1.1')
testFeatures
%clear
trainFeatures[0]
trainFeatures[0][0]
runfile('C:/Users/vatsal/OneDrive/Sentiment_Module_Twitter_1.1/final_demo_v1.1.py', wdir='C:/Users/vatsal/OneDrive/Sentiment_Module_Twitter_1.1')
%clear
runfile('C:/Users/vatsal/OneDrive/Sentiment_Module_Twitter_1.1/final_demo_v1.1.py', wdir='C:/Users/vatsal/OneDrive/Sentiment_Module_Twitter_1.1')