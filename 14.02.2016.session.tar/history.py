s = "cat bat mat cat bat cat" 
# *** Spyder Python Console History Log ***
wordlist = [word for word in s.split(" ")]
for i in range(len(wordlist)):
    value = 1
    for j in range(i+1,len(wordlist)):
        
        for k in range(len(freq)):
            if wordlist[i] != freq[k][0]:
                flag = 1
            else:
                flag = 0
                break            
        
        if flag==1 and wordlist [i] == wordlist[j]:
            value=value+1    
    freq.append((wordlist[i],value))

freq
s = "cat bat mat cat bat cat" 
freq = []
wordlist = [word for word in s.split(" ")]
for i in range(len(wordlist)):
    value = 1
    for j in range(i+1,len(wordlist)):
        
        for k in range(len(freq)):
            if wordlist[i] != freq[k][0]:
                flag = 1
            else:
                flag = 0
                break            
        if flag==1 and wordlist [i] == wordlist[j]:
            value=value+1   
    
    freq.append((wordlist[i],value))

s = "cat bat mat cat bat cat" 
freq = {}
wordlist = [word for word in s.split(" ")]
for word in wordlist:
    if word not in freq:
        freq[word] = 1
    else:
        freq[word] += 1

%reset
%clear
sorted_freq = sorted(freq.values)
s = "cat bat mat cat bat cat" 
freq = {}
wordlist = [word for word in s.split(" ")]
for word in wordlist:
    if word not in freq:
        freq[word] = 1
    else:
        freq[word] += 1

sorted_freq = sorted(freq.values)
sorted_freq = sorted(freq.values())
sorted_freq = sorted(freq.values(),key=operator.itemgetter(1)).reverse()
import operator
sorted_freq = sorted(freq.values(),key=operator.itemgetter(1)).reverse()
sorted_freq = sorted(freq.values(),key=operator.itemgetter(1))
sorted_freq = sorted(freq.values(),key=lambda x:x[1])
sorted_freq = sorted(freq.values())
sorted_freq = sorted(freq.items(),key=lambda x:x[1])
sorted_freq = sorted(freq.items(),key=lambda x:x[1],reverse=True)
sorted_freq[0:2]
runfile('C:/Users/vatsal/OneDrive/leetcode/Word Count.py', wdir='C:/Users/vatsal/OneDrive/leetcode')
sorted_freq = sorted(freq.items(),key=lambda x:x[1],reverse=True)
runfile('C:/Users/vatsal/OneDrive/leetcode/Word Count.py', wdir='C:/Users/vatsal/OneDrive/leetcode')

##---(Sun Feb 14 15:29:43 2016)---
import tweepy
import tweepy
%clear
python -v
python -v
runfile('C:/Users/vatsal/OneDrive/Sentiment_Python/stream_tweets.py', wdir='C:/Users/vatsal/OneDrive/Sentiment_Python')
from tweepy import Stream
from tweepy import OAuthHandler
from tweepy import StreamListener

consumerkey = 'KuMYXgdFWRv5cbGx4iVUhrsdb'
secretkey =  ' 1cI2FPyzM8ru2yvWmhuw7a9ZZQiKqkI98yT0OrG0q4CRmkyNH5'
access_token = '162372886-NVDklSBmTlUjJCKDrHT0GafWSZMobSeldr4ba75R' 
access_secret = 'WSWdH9UD2p470vwVeQMhLfciERjgBna0XMxvi7hoV9avx'
auth = OAuthHandler(consumerkey, secretkey)
auth.set_access_token(access_token, access_secret)
class listener(StreamListener):
    
    def on_data(self, data):
        print(data)
        return(True)
    
    def on_error(self, status):
        print(status)

twitterStream = Stream(auth, listener())
twitterStream.filter(track=["Valentines"])
runfile('C:/Users/vatsal/OneDrive/Sentiment_Python/stream_tweets.py', wdir='C:/Users/vatsal/OneDrive/Sentiment_Python')

##---(Mon Feb 15 00:43:34 2016)---
runfile('C:/Users/vatsal/OneDrive/Sentiment_Python/stream_tweets.py', wdir='C:/Users/vatsal/OneDrive/Sentiment_Python')
%clear
runfile('C:/Users/vatsal/OneDrive/Sentiment_Python/stream_tweets.py', wdir='C:/Users/vatsal/OneDrive/Sentiment_Python')
%clear